/**
 * Add Your Custom Javascript Code
 */
$(document).ready(function(){
  /**
   * Your Jquery Code
   */
});