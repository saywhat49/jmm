DROP TABLE IF EXISTS `#__jmm_canned_queries`;
DROP TABLE IF EXISTS `#__jmm_sitetables`;
DROP TABLE IF EXISTS `#__jmm_templates`;