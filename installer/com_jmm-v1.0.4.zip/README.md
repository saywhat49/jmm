### Welcome to JMM Joomla Mysql Manager.

JMM is a Joomla Extension for managing Mysql Datbase from the joomla administrator panel.

### How to Install JMM

Download Latest Zip File From here http://adidac.github.com/jmm/ . Login to your joomla administrator
panel go to Extension Manger from Extensions Menu then click on Select or Browse File Icon select your recently downloaded JMM Zip File. Then Click on Install.After successfull installation Click on componnent Menu you can see Joomla Mysql Manager Menu click here and start JMM. 

### JMM Features?

* You can View All Database Lists
* You Can View All the Tables Within a Database
* You can Run your Custom Query
* You can Save Your Query for Future as Bookmark using Canned Query.

### Authors and Contributors

@adidac Biswarup Adhikari.

### Support or Contact

For any Problem,Bugs,Feedback you can email me at biswarupadhikari@gmail.com.

### Licence

The GNU General Public License
http://www.gnu.org/licenses/gpl.txt
Copyright (c) 2012 Biswarup Adhikari