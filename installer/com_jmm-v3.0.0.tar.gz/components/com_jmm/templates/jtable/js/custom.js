$(document).ready(function(){
//alert("Jtable");
});