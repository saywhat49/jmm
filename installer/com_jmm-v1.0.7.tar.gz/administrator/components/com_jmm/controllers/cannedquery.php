<?php
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');
class JMMControllerCannedQuery extends JControllerForm
{	
	protected $view_list='cannedqueries';

}
