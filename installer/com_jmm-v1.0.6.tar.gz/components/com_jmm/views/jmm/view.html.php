<?php
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');
class JMMViewJMM extends JView
{

	function display($tmpl=null) 
	{
        parent::display($tmpl);
	}
}