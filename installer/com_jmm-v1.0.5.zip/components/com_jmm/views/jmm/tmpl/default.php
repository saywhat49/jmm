<?php
defined('_JEXEC') or die('Restricted access');
?>