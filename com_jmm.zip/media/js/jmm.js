var JQ = jQuery.noConflict();
JQ('document').ready(function(){

});