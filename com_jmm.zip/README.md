### Welcome to JMM Joomla Mysql Manager.

JMM is a Joomla Extension for managing Mysql Datbase from the joomla administrator panel.

### How to Install JMM

Download Latest Zip File From here https://github.com/saywhat49/jmm. Login to your joomla administrator
panel go to Extension Manger from Extensions Menu then click on Select or Browse File Icon select your recently downloaded JMM Zip File. Then Click on Install.After successfull installation Click on componnent Menu you can see Joomla Mysql Manager Menu click here and start JMM. 


### JMM Features?

* Insert Data into Table via GUI
* Create Table via GUI
* Export Table,Custom Query in CSV format
* You can View All Database Lists
* You Can View All the Tables Within a Database
* You can Run your Custom Query
* You can Save Your Query for Future as Bookmark using Canned Query OR Save as Site Table.
* You can Generate Visual Table In the Frontend From Your Query,you can enable pagination also.
* Now has template system where user can select theme or they can step further by customize the looks using css and javascript or jquery.

### Authors and Contributors

@adidac Biswarup Adhikari.
Fork by saywhat49

### Support or Contact

For any Problem,Bugs,Feedback you can email me at ...

### Licence

The GNU General Public License
http://www.gnu.org/licenses/gpl.txt
Copyright (c) 2012 Biswarup Adhikari
