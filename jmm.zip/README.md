### Welcome to JMM Joomla Mysql Manager.

JMM is a Joomla Extension for managing Mysql Datbase from the joomla administrator panel.

### How to Install JMM

Download Latest Zip File From here http://adidac.github.com/jmm/ . Login to your joomla administrator
panel go to Extension Manger from Extensions Menu then click on Select or Browse File Icon select your recently downloaded JMM Zip File. Then Click on Install.After successfull installation Click on componnent Menu you can see Joomla Mysql Manager Menu click here and start JMM. 

### JMM Features?

* You can View All Database Lists
* You Can View All the Tables Within a Database
* You can Run your Custom Query
* You can Save Your Query for Future as Bookmark using Canned Query.

### Authors and Contributors

@adidac Biswarup Adhikari.

### Support or Contact

For any Problem,Bugs,Feedback you can email me at biswarupadhikari@gmail.com.

### Licence

The MIT License

Copyright (c) 2012 Biswarup Adhikari

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.