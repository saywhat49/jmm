<?php
$params=JFactory::getApplication()->getParams();
$dbHost=$params->get('dbhost');
$dbUsername=$params->get('dbusername');
$dbPass=$params->get('dbpass');
$dbName=$params->get('dbname');
?>